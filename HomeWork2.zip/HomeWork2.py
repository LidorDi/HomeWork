# Assignment 1

num1: int = int(input("Enter num1"))
num2: int = int(input("Enter num2"))
num3: int = int(input("Enter num3"))
multiplication: int = num1 * num2 * num3
addup: int = num1 + num2 + num3
print(addup)
print(multiplication)

# Assignment 2

num11: float = float(input("Enter floatNum1"))
num12: float = float(input("Enter floatNum2"))
if num11 > num12:
    diff: float = num11 - num12
else:
    diff: float = num12 - num11
print(diff)

# Assignment 3

word1: str = str(input("Enter word1"))
word2: str = str(input("Enter word1"))
print("*" + word1 + "*" + word2 + "*")
print("-" + word1 + "-" + word2 + "-")

# Assignment 4

a: int = int(input("Enter Num1"))
b: int = int(input("Enter Num2"))
if a > b:
    print(a)
else:
    print(b)

# Assignment 5

c: int = int(input("Enter Num1"))
d: int = int(input("Enter Num2"))
if c>d :
    print(d)
    print(c)
else:
    print(c)
    print(d)

