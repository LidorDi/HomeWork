# FIRST ASSIGNMENT
print("First Assignment")
x = input("write a number")
print(x)
print(x)
print(x)
# SECOND ASSIGNMENT
print("Second Assignment")
x = 777
y = 888
z = 999
result = x*y+z
print(result)
input("END")
#END